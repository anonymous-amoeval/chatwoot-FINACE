import 'dart:async';
import 'dart:convert';

import 'package:dio/dio.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart' hide Response;
import 'package:gpstatus/controllers/my_controller.dart';
import 'package:gpstatus/helpers/widgets/my_text.dart';
import 'package:logger/logger.dart';


class DashboardController extends MyController {
  List<Map<String, dynamic>> kycData = [];
  Logger logger = Logger();
  // 定时器，每2秒钟刷新一次
  late Timer timer;

  @override
  void onInit() {
    super.onInit();
    // 每2秒钟刷新一次
    timer = Timer.periodic(const Duration(seconds: 3), (timer) {
      getKycData();
    });
  }

  Future<void> getKycData() async {
    List<Map<String, dynamic>> kycDataTemp = [];
    String apiUrl = 'https://webapi.207777.xyz/getallkycstatus';
    try {
      // dio请求
      logger.i('请求KYC数据');
      Response response = await Dio().get(apiUrl);
      // 解析JSON数组
      List<dynamic> nestedList = response.data;

      for (var item in nestedList) {
        if (item is Map<String, dynamic>) {
          // 遍历Map中的所有键值对
          item.forEach((key, value) {
            if (value is String) {
              // 尝试解析字符串值，以确认是否是JSON字符串
              try {
                // 如果value是有效的JSON字符串，它将被解析
                final parsedJson = jsonDecode(value);
                // 替换原始字符串value为解析后的Map或List
                item[key] = parsedJson;
              } catch (e) {
                // 如果jsonDecode抛出异常，则value不是JSON字符串
                // 这里不做任何操作，保留原始的value
              }
            }
          });
          // 将已可能更新的item添加到kycData
          kycDataTemp.add(item);
        }
      }
    } catch (e) {
      print(e);
    }
    kycData = kycDataTemp;
    update();
  }

  Future<void> startKYC(String userEmail) async {
    String apiUrl = 'https://webapi.207777.xyz/startkyc';
    try {
      // dio请求
      logger.i('开始KYC');
      // POST请求体中有一个email字段
      Response response = await Dio().post(apiUrl, data: {'email': userEmail});
    } catch (e) {
      print(e);
    }
  }

  Future<void> updateKYC(String userEmail, String status) async {
    String apiUrl = 'https://webapi.207777.xyz/updatekycstatus';
    try {
      // dio请求
      logger.i('更新KYC');
      // POST请求体中有email和status字段
      Response response = await Dio().post(apiUrl, data: {'email': userEmail, 'kyc_status': status});
    } catch (e) {
      print(e);
    }
  }
}

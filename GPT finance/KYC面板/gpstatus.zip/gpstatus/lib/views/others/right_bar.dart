import 'package:gpstatus/helpers/theme/theme_customizer.dart';
import 'package:gpstatus/helpers/utils/mixins/ui_mixin.dart';
import 'package:gpstatus/helpers/widgets/my_spacing.dart';
import 'package:gpstatus/helpers/widgets/my_text.dart';
import 'package:gpstatus/widgets/custom_switch.dart';
import 'package:flutter/material.dart';

class RightBar extends StatefulWidget {

  const RightBar({
    Key? key,
  }) : super(key: key);

  @override
  _RightBarState createState() => _RightBarState();
}

class _RightBarState extends State<RightBar>
    with SingleTickerProviderStateMixin, UIMixin {
  ThemeCustomizer customizer = ThemeCustomizer.instance;

  @override
  void initState() {
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    customizer = ThemeCustomizer.instance;
    return Container(
      width: 280,
      color: colorScheme.background,
      child: Column(
        children: [
          Container(
            height: 60,
            alignment: Alignment.centerLeft,
            padding: MySpacing.x(24),
            color: colorScheme.primaryContainer,
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Expanded(
                  child: MyText.labelLarge(
                    "Settings",
                    color: colorScheme.onPrimaryContainer,
                  ),
                ),
                InkWell(
                  onTap: () {
                    Navigator.of(context).pop();
                  },
                  child: Icon(
                    Icons.close,
                    size: 18,
                    color: colorScheme.onPrimaryContainer,
                  ),
                )
              ],
            ),
          ),
          Expanded(
              child: Container(
            padding: MySpacing.all(24),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                MyText.labelMedium("Color Scheme"),
                Divider(),
                MySpacing.height(8),
                Row(
                  children: [
                    CustomSwitch.small(
                      value: customizer.theme == ThemeMode.light,
                      onChanged: (value) {
                        ThemeCustomizer.setTheme(ThemeMode.light);
                      },
                    ),
                    MySpacing.width(12),
                    Text(
                      "Light",
                    )
                  ],
                ),
                MySpacing.height(8),
                Row(
                  children: [
                    CustomSwitch.small(
                      value: customizer.theme == ThemeMode.dark,
                      onChanged: (value) {
                        ThemeCustomizer.setTheme(ThemeMode.dark);
                      },
                    ),
                    MySpacing.width(12),
                    Text(
                      "Dark",
                    )
                  ],
                ),
                Divider(),
                // Spacing.height(8),
                // Row(
                //   children: [
                //     CustomSwitch.small(
                //       value: widget.leftBarThemeType == LeftBarThemeType.light,
                //       activeBorderColor: rightBarTheme.activeSwitchBorderColor,
                //       inactiveBorderColor: rightBarTheme.inactiveSwitchBorderColor,
                //       inactiveTrackColor: rightBarTheme.disabled,
                //       activeTrackColor: rightBarTheme.primary,
                //       inactiveThumbColor: rightBarTheme.onDisabled,
                //       activeThumbColor: rightBarTheme.onPrimary,
                //       onChanged: (value) {
                //         if (value && widget.onLeftBarColorSchemeChange != null) {
                //           widget.onLeftBarColorSchemeChange(LeftBarThemeType.light);
                //         }
                //       },
                //     ),
                //     Spacing.width(12),
                //     Text(
                //       "Light",
                //       style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                //           color: rightBarTheme.onBackground),
                //     )
                //   ],
                // ),
                // Spacing.height(8),
                // Row(
                //   children: [
                //     CustomSwitch.small(
                //       value: widget.leftBarThemeType == LeftBarThemeType.dark,
                //       activeBorderColor: rightBarTheme.activeSwitchBorderColor,
                //       inactiveBorderColor: rightBarTheme.inactiveSwitchBorderColor,
                //       inactiveTrackColor: rightBarTheme.disabled,
                //       activeTrackColor: rightBarTheme.primary,
                //       inactiveThumbColor: rightBarTheme.onDisabled,
                //       activeThumbColor: rightBarTheme.onPrimary,
                //       onChanged: (value) {
                //         if (value && widget.onLeftBarColorSchemeChange != null) {
                //           widget.onLeftBarColorSchemeChange(LeftBarThemeType.dark);
                //         }
                //       },
                //     ),
                //     Spacing.width(12),
                //     Text(
                //       "Dark",
                //       style: AppTheme.getTextStyle(themeData.textTheme.bodyText2,
                //           color: rightBarTheme.onBackground),
                //     )
                //   ],
                // ),
                // Spacing.height(36),
                Text("Top Bar"),
                Divider(),
              ],
            ),
          ))
        ],
      ),
    );
  }
}

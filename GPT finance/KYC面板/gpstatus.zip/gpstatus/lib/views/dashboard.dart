import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:gpstatus/controllers/dashboard_controller.dart';
import 'package:gpstatus/helpers/theme/app_style.dart';
import 'package:gpstatus/helpers/utils/mixins/ui_mixin.dart';
import 'package:gpstatus/helpers/widgets/my_button.dart';
import 'package:gpstatus/helpers/widgets/my_container.dart';
import 'package:gpstatus/helpers/widgets/my_flex.dart';
import 'package:gpstatus/helpers/widgets/my_flex_item.dart';
import 'package:gpstatus/helpers/widgets/my_spacing.dart';
import 'package:gpstatus/helpers/widgets/my_text.dart';
import 'package:gpstatus/models/job_vacancee.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:get/instance_manager.dart';
import 'package:get/state_manager.dart';
import '../helpers/widgets/my_card.dart';
import 'others/layout.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  DashboardPageState createState() => DashboardPageState();
}

class DashboardPageState extends State<DashboardPage>
    with SingleTickerProviderStateMixin, UIMixin {
  late DashboardController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.put(DashboardController());
  }

  @override
  Widget build(BuildContext context) {
    return Layout(
      child: GetBuilder(
        init: controller,
        builder: (controller) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: MySpacing.x(flexSpacing),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    MyText.titleMedium(
                      "用户KYC状态面板",
                      fontWeight: 600,
                      fontSize: 18,
                    ),
                  ],
                ),
              ),
              MySpacing.height(flexSpacing),
              Padding(
                padding: MySpacing.x(flexSpacing),
                child: MyFlex(
                  children: [
                    MyFlexItem(
                      sizes: "lg-8",
                      child: GridView.builder(
                        shrinkWrap: true,
                        gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 350,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                          mainAxisExtent: 520,
                        ),
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        itemCount: controller.kycData.length,
                        itemBuilder: (BuildContext context, int index) {
                          return SingleChildScrollView(
                            child: MyCard(
                                borderRadiusAll: 10,
                                padding: const EdgeInsets.fromLTRB(8, 4, 8, 4),
                                child: Column(
                                  children: [
                                    // 名字
                                    MyContainer(
                                      child: Row(
                                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                        children: [
                                          MyText.titleLarge(
                                            controller.kycData[index]["user_type"] == "individual" ? controller.kycData[index]['user_data_gp']["name"] : controller.kycData[index]['user_data_gp']["accountHolderName"],
                                            // fontSize: 16,
                                            fontWeight: 700,
                                            overflow: TextOverflow.clip,
                                          ),
                                          MyText.titleMedium(
                                            controller.kycData[index]["user_type"] == "individual" ? "个人用户" : "公司用户",
                                            // fontSize: 14,
                                            // fontWeight: 700,
                                            overflow: TextOverflow.clip,
                                          ),
                                          // 显示状态
                                          controller.kycData[index]["status"] == null ? MyText.bodyMedium("等待中", color: Colors.grey) :
                                          controller.kycData[index]["status"] == "pass" ? MyText.bodyMedium("已通过", color: Colors.green) :
                                          controller.kycData[index]["status"] == "info needed" ? MyText.bodyMedium("人工审查中", color: Colors.yellow) :
                                          controller.kycData[index]["status"] == "failed" ? MyText.bodyMedium("已拒绝", color: Colors.red)
                                              : Container()
                                        ],
                                      ),
                                    ),
                                    // MySpacing.height(flexSpacing),
                                    _buildExpansionPanelRadioList(controller.kycData[index]),
                                    MySpacing.height(8),
                                    MyButton.block(
                                        onPressed: () {
                                          Get.find<DashboardController>().startKYC(controller.kycData[index]["user_email"]);
                                        },
                                        child:
                                        MyText.bodyMedium("重启KYC", color: theme.colorScheme.onPrimary)
                                    ),
                                    MySpacing.height(8),
                                    SizedBox(
                                      // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                                      height: 50,
                                      width: double.infinity,
                                      child: Wrap(
                                        direction: Axis.horizontal,
                                        alignment: WrapAlignment.spaceBetween,
                                        children: [
                                          // 三个按钮，带图标，分别为通过，补充资料，拒绝
                                          MyButton.small(
                                              onPressed: () async {
                                                // 通过
                                                await Get.find<DashboardController>().updateKYC(controller.kycData[index]["user_email"], "pass");
                                                // 提示用户
                                                Get.snackbar("KYC状态更新", "KYC状态已更新为通过", snackPosition: SnackPosition.BOTTOM);
                                              },
                                            backgroundColor: Colors.green,
                                              child: Wrap(
                                                alignment: WrapAlignment.center,
                                                crossAxisAlignment: WrapCrossAlignment.center,
                                                children: [
                                                  Icon(
                                                      Icons.check_circle,
                                                      color: theme.colorScheme.onPrimary,
                                                    size: 16,
                                                  ),
                                                  MySpacing.width(4),
                                                  MyText.bodyMedium("通过", color: theme.colorScheme.onPrimary)
                                                ],
                                              ),
                                              // padding: const EdgeInsets.fromLTRB(0, 0, 0, 0),
                                          ),
                                          MyButton.small(
                                            backgroundColor: Colors.yellow,
                                              onPressed: () async {
                                                // 补充资料
                                                await Get.find<DashboardController>().updateKYC(controller.kycData[index]["user_email"], "info needed");
                                                // 提示用户
                                                Get.snackbar("KYC状态更新", "KYC状态已更新为需要更多资料", snackPosition: SnackPosition.BOTTOM);
                                              },
                                              child:
                                              Wrap(
                                                alignment: WrapAlignment.center,
                                                crossAxisAlignment: WrapCrossAlignment.center,
                                                children: [
                                                  Icon(
                                                      Icons.warning_amber,
                                                      color: theme.colorScheme.onPrimary,
                                                    size: 16,
                                                  ),
                                                  MySpacing.width(4),
                                                  MyText.bodyMedium("审查", color: theme.colorScheme.onPrimary)
                                                ],
                                              )
                                          ),
                                          MyButton.small(
                                              onPressed: () {
                                                // 拒绝
                                                Get.find<DashboardController>().updateKYC(controller.kycData[index]["user_email"], "failed");
                                                // 提示用户
                                                Get.snackbar("KYC状态更新", "KYC状态已更新为拒绝", snackPosition: SnackPosition.BOTTOM);
                                              },
                                            backgroundColor: Colors.red,
                                              child:
                                              Wrap(
                                                alignment: WrapAlignment.center,
                                                crossAxisAlignment: WrapCrossAlignment.center,
                                                children: [
                                                  Icon(
                                                      Icons.cancel,
                                                      color: theme.colorScheme.onPrimary,
                                                    size: 16,
                                                  ),
                                                  MySpacing.width(4),
                                                  MyText.bodyMedium("拒绝", color: theme.colorScheme.onPrimary)
                                                ],
                                              ),
                                          ),
                                        ],
                                      )
                                    )
                                  ],
                                )
                            ),
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }

  Widget _buildStatusRow(constraints, data, currentGroupKey, groupPassColor) {
    // 这里只需要写上名字和状态即可
    String checkItem = "";
    if (currentGroupKey == "id_1") {
      checkItem = "ID证件1";
    } else if (currentGroupKey == "id_2") {
      checkItem = "ID证件2";
    } else if (currentGroupKey == "kyc_membercheck") {
      checkItem = "Membercheck检查";
    } else if (currentGroupKey == "kyc_google") {
      checkItem = "谷歌搜索分析";
    } else if (currentGroupKey == "kyc_baidu") {
      checkItem = "百度搜索分析";
    } else if (currentGroupKey == "kyc_tianyancha") {
      checkItem = "天眼查搜索分析";
    // } else if (currentGroupKey == "kyc_zgzxxxgkw") {
    //   checkItem = "中国执行信息公开网查询分析";
    } else if (currentGroupKey == "kyc_company_baidu") {
      checkItem = "公司百度搜索分析";
    } else if (currentGroupKey == "kyc_company_google") {
      checkItem = "公司谷歌搜索分析";
    } else if (currentGroupKey == "kyc_company_tianyancha") {
      checkItem = "公司天眼查搜索分析";
    } else if (currentGroupKey == "kyc_company_abn_lookup") {
      checkItem = "澳洲公司ABN查询";
    }
    return MyContainer(
      // width: constraints.widthConstraints().maxWidth,
      padding: const EdgeInsets.fromLTRB(8, 0, 8, 0),
      margin: const EdgeInsets.fromLTRB(0, 0, 0, 0),
      child: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Row(children: [
                  Flexible(
                      child: MyText.titleSmall(
                        checkItem,
                        height: 1.2,
                        fontWeight: 700,
                        overflow: TextOverflow.ellipsis,
                        maxLines: null,
                      )),
                ]),
              ],
            )),
            // 状态打勾或者叉，方便查看
            data[currentGroupKey]["status"] == "processing" ? SizedBox(
              width: 20,
              height: 20,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(theme.colorScheme.onSurface),
                strokeWidth: 3,
              ),
            ) :
            Icon(
              data[currentGroupKey]["status"] == "waiting" ? Icons.timelapse : data[currentGroupKey]["status"] == "attention" ?
              Icons.warning_amber :
              data[currentGroupKey]["status"] == "pass"
                  ? Icons.check_circle
                  : Icons.cancel,
              color: data[currentGroupKey]["status"] == "waiting" ?
              Colors.black26 : data[currentGroupKey]["status"] == "attention" ?
              Colors.amber
                  :data[currentGroupKey]["status"] == "pass"
                  ? Colors.green
                  : Colors.red,
              size: 24,
            ),
      ]),
    );
  }

  List<ExpansionPanelRadio> _buildExpansionPanelList(Map<String, dynamic> data) {
    List<ExpansionPanelRadio> items = [];
    // 如果是个人用户
    List<String> keys = [];
    if (data["user_type"] == "individual") {
      keys = ["id_1", "id_2", "kyc_membercheck", "kyc_google", "kyc_baidu", "kyc_tianyancha"]; //可以添加, "kyc_zgzxxxgkw"
    } else {
      keys = ["id_1", "id_2", "kyc_membercheck", "kyc_google", "kyc_baidu", "kyc_tianyancha", "kyc_company_baidu", "kyc_company_google", "kyc_company_tianyancha", "kyc_company_abn_lookup"];
    }

    for (int i = 0; i < keys.length; i++) {
      String currentGroupKey = keys[i];
      items.add(
        ExpansionPanelRadio(
          value: i,
          // 唯一标识这个面板
          backgroundColor: theme.colorScheme.background,
          canTapOnHeader: true,
          headerBuilder: (BuildContext context, bool isExpanded) {
            String status = data[currentGroupKey]["status"];
            Color groupPassColor = const Color.fromRGBO(0, 128, 0, 1);
            if (status == "pass") {
              groupPassColor = const Color.fromRGBO(0, 128, 0, 1);
            } else if (status == "attention"){
              groupPassColor = const Color.fromRGBO(255, 165, 0, 1);
            }
            else {
              groupPassColor = const Color.fromRGBO(255, 0, 0, 1);
            }

            return LayoutBuilder(builder: (context, constraints) {
              return _buildStatusRow(
                  constraints,
                  data,
                  currentGroupKey,
                  groupPassColor);
            });
          },
          body: Column(
              children: [
            Wrap(
              // 只需要显示一个message和一个查看原始数据的按钮，用Container之类的就行
              children: [
                MyContainer(
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.start,
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      MyText.titleMedium(
                        "GPT分析结果",
                        fontSize: 16,
                        fontWeight: 700,
                      ),
                      MySpacing.height(flexSpacing),
                      MyText.bodyMedium(
                        data[currentGroupKey]["message"],
                        fontSize: 14,
                      ),
                      MySpacing.height(flexSpacing),
                      Divider(
                        color: theme.colorScheme.onSurface,
                        thickness: 1,
                      ),
                      MyButton.block(
                          onPressed: () {
                            // 打开原始数据

                          },
                          child:
                          MyText.bodyMedium("查看原始数据", color: theme.colorScheme.onPrimary)
                      ),
                      MyButton.block(
                          onPressed: () {
                            // 打开原始数据

                          },
                          child:
                          MyText.bodyMedium("重启KYC", color: theme.colorScheme.onPrimary)
                      )
                    ],
                  ),
                )
              ],
            ),
          ]),
        ),
      );
    }
    return items;
  }

  Widget _buildExpansionPanelRadioList(Map<String, dynamic> data) {
    return ExpansionPanelList.radio(
      animationDuration: const Duration(milliseconds: 500),
      expansionCallback: (int index, bool isExpanded) async {
      },
      children: _buildExpansionPanelList(data),
    );
  }
}





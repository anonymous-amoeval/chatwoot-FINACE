import 'package:gpstatus/controllers/job_vacancee_controller.dart';
import 'package:gpstatus/helpers/theme/app_style.dart';
import 'package:gpstatus/helpers/utils/mixins/ui_mixin.dart';
import 'package:gpstatus/helpers/widgets/my_container.dart';
import 'package:gpstatus/helpers/widgets/my_flex.dart';
import 'package:gpstatus/helpers/widgets/my_flex_item.dart';
import 'package:gpstatus/helpers/widgets/my_progress_bar.dart';
import 'package:gpstatus/helpers/widgets/my_spacing.dart';
import 'package:gpstatus/helpers/widgets/my_text.dart';
import 'package:gpstatus/models/job_vacancee.dart';
import 'package:gpstatus/views/others/layout.dart';
import 'package:flutter/material.dart';
import 'package:get/get_state_manager/get_state_manager.dart';
import 'package:get/instance_manager.dart';
import 'package:lucide_icons/lucide_icons.dart';

class JobVacanciesPage extends StatefulWidget {
  const JobVacanciesPage({Key? key}) : super(key: key);

  @override
  State<JobVacanciesPage> createState() => _JobVacanciesPageState();
}

class _JobVacanciesPageState extends State<JobVacanciesPage>
    with SingleTickerProviderStateMixin, UIMixin {
  late JobVacanceeController controller;

  @override
  void initState() {
    super.initState();
    controller = Get.put(JobVacanceeController());
  }

  @override
  Widget build(BuildContext context) {
    return Layout(
      child: GetBuilder(
        init: controller,
        builder: (controller) {
          return Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Padding(
                padding: MySpacing.x(flexSpacing),
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    MyText.titleMedium(
                      "用户订单审查面板",
                      fontWeight: 600,
                      fontSize: 18,
                    ),
                  ],
                ),
              ),
              MySpacing.height(flexSpacing),
              Padding(
                padding: MySpacing.x(flexSpacing),
                child: MyFlex(
                  children: [
                    MyFlexItem(
                      sizes: "lg-8",
                      child: GridView.builder(
                        shrinkWrap: true,
                        gridDelegate: SliverGridDelegateWithMaxCrossAxisExtent(
                          maxCrossAxisExtent: 350,
                          crossAxisSpacing: 16,
                          mainAxisSpacing: 16,
                          mainAxisExtent: 230,
                        ),
                        clipBehavior: Clip.antiAliasWithSaveLayer,
                        itemCount: controller.jobVacancee.length,
                        itemBuilder: (BuildContext context, int index) {
                          return JobVacanceeWidget(
                            jobVacancee: controller.jobVacancee[index],
                          );
                        },
                      ),
                    ),
                  ],
                ),
              ),
            ],
          );
        },
      ),
    );
  }
}

class JobVacanceeWidget extends StatefulWidget {
  final JobVacancee jobVacancee;

  const JobVacanceeWidget({
    required this.jobVacancee,
    Key? key,
  }) : super(key: key);

  @override
  State<JobVacanceeWidget> createState() => _JobVacanceeWidgetState();
}

class _JobVacanceeWidgetState extends State<JobVacanceeWidget> with UIMixin {
  late JobVacancee jobVacancee;
  bool isSave = false;

  @override
  void initState() {
    super.initState();
    jobVacancee = widget.jobVacancee;
  }

  @override
  Widget build(BuildContext context) {
    return MyContainer.none(
      paddingAll: 16,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Row(
            children: [
              MyContainer.none(
                borderRadiusAll: 22,
                clipBehavior: Clip.antiAliasWithSaveLayer,
                child: Image.asset(
                  jobVacancee.image,
                  height: 44,
                  width: 44,
                  fit: BoxFit.cover,
                ),
              ),
              MySpacing.width(12),
              Expanded(
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.start,
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    MyText.bodyMedium(
                      jobVacancee.companyName,
                      fontSize: 16,
                    ),
                    MyText.bodySmall(
                      jobVacancee.appName,
                    ),
                  ],
                ),
              ),
              Row(
                children: [
                  IconButton(
                    onPressed: () {
                      setState(() {
                        isSave = !isSave;
                      });
                    },
                    icon: Icon(
                        !isSave
                            ? Icons.bookmark_outline
                            : Icons.bookmark_outlined,
                        size: 24,
                        color: contentTheme.primary),
                  ),
                ],
              ),
            ],
          ),
          Row(
            children: [
              Icon(
                LucideIcons.map,
                size: 20,
              ),
              MySpacing.width(8),
              MyText.bodyMedium(
                jobVacancee.location,
              ),
            ],
          ),
          Row(
            children: [
              Icon(
                LucideIcons.briefcase,
                size: 20,
              ),
              MySpacing.width(8),
              MyText.bodyMedium(
                "${jobVacancee.years} Years",
                overflow: TextOverflow.ellipsis,
              ),
            ],
          ),
          MyProgressBar(
            width: 300,
            progress: jobVacancee.progress,
            height: 3,
            radius: 4,
            inactiveColor: theme.dividerColor,
            activeColor: colorScheme.primary,
          ),
          Row(
            children: [
              Expanded(
                child: MyText.bodyMedium(
                  "6 of 15 Filled",
                  overflow: TextOverflow.ellipsis,
                ),
              ),
              MyText.bodyMedium(
                "Upload ${jobVacancee.years} Hours ago",
              ),
            ],
          ),
        ],
      ),
    );
  }
}

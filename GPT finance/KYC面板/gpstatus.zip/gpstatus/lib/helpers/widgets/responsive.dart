import 'package:gpstatus/helpers/widgets/my_screen_media.dart';

export 'my_display_type.dart';
export 'my_screen_media.dart';
export 'my_screen_media_type.dart';

double get flexSpacing => MyScreenMedia.flexSpacing;

int get flexColumns => MyScreenMedia.flexColumns;

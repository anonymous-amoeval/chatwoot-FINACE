import 'package:gpstatus/views/job_vacancee_page.dart';
import 'package:gpstatus/views/dashboard.dart';
import 'package:get/get.dart';

getPageRoute() {
  var routes = [
    GetPage(
        name: '/dashboard',
        page: () => DashboardPage()),
    GetPage(
        name: '/orders',
        page: () => JobVacanciesPage(),
        ),
  ];

  return routes
      .map((e) => GetPage(
          name: e.name,
          page: e.page,
          middlewares: e.middlewares,
          transition: Transition.noTransition))
      .toList();
}
